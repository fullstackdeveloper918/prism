*** Kona Core (custom post types, page builder,widgets,shortcodes,...) ***


October 01 2018 - Version 1.0
	
	* First Release

